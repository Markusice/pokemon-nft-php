<?php

declare(strict_types=1);

/**
 * @var array $cards
 */

$cardsPerPage = 9;
$totalPages = ceil(count($cards) / $cardsPerPage);
