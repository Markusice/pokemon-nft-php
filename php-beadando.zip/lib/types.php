<?php

$types = ['normal', 'fire', 'water', 'electric', 'grass', 'ice', 'fighting', 'poison', 'ground', 'physic', 'bug', 'rock', 'ghost', 'dark', 'steel'];
