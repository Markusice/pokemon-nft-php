<?php

enum AccountTab: string
{
    case Profile = 'profile';
    case Cards = 'cards';
    case AdminPanel = 'admin panel';
}
