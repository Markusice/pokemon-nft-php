<footer>
    <p>IKémon | ELTE IK Webprogramozás</p>
</footer>